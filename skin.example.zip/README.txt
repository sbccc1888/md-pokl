将皮肤包解压后用相同名称的素材文件替换，然后重新打包即可使用。
注意：不可替换判定线、暂停按钮和打击粒子的贴图。

Unzip this skinpack and replace assets with SAME filename, then rezip these to use.
Note that judgeline, pause button and hit particle cannot be changed.